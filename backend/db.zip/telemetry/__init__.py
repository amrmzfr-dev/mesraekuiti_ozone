default_app_config = 'telemetry.apps.TelemetryConfig'

